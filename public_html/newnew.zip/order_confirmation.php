<div class="">
  <h1>Order Confirmation</h1>
  <p>Thank you for your order!</p>
  <p>Your order has been received and will be processed shortly.</p>
   <a class="prodlink" href="index.php">continue shopping</a>
  </div>