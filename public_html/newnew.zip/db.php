<?php
    $conn = mysqli_connect("localhost", "id20192373_amakipkip",")K@7lbP-detYwc<q", "id20192373_ama_express");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
}
session_start();
?>
